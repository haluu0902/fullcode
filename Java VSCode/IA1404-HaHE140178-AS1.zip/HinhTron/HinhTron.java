import java.util.Scanner;
public class HinhTron {

    public static void main(String[] args) {
        float r;
        Circle hT = new Circle();
        Scanner sc = new Scanner(System.in);
        System.out.print("Input radius r = ");
        r=sc.nextFloat();
        hT.setR(r);        
        float primeter = hT.computePrimeter();
        float area = hT.computeArea();
        System.out.printf("Diameter of a circle: %.2f\n", primeter);
        System.out.printf("Circle area: %.2f\n", area);
    }
}


