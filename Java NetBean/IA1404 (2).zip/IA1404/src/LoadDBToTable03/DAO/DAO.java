
package LoadDBToTable03.DAO;
import LoadDBToTable03.Entity.Student;
import context.DBContext;
import java.sql.*;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
/**
 *
 * @author LTTH
 */
public class DAO {
    private Connection con;
    private List<Student> student;

    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

    public List<Student> getStudent() {
        return student;
    }

    public void setStudent(List<Student> student) {
        this.student = student;
    }
    
    public DAO(){
        initConnection();
    }

    private void initConnection() {
        try{
            con = new DBContext().getConnection();
        }catch(Exception e){
            
        }
    }    
    HashSet<String> hs;
    public void getListStudent(String sql){
        hs = new HashSet<String>();
        student = new Vector<Student>(); // Vecto co dong bo, ArrayList thi khong
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                hs.add(rs.getString(1));
                student.add(new Student(
                        rs.getString(1), rs.getString(2), rs.getBoolean(3),
                        rs.getString(4), Float.parseFloat(rs.getString(5)),
                        rs.getString(6)
                ));
            }
        }catch(Exception e){
        }
    }
    
    void putListToDB(){
//        Vector <Student> vec = new Vector<Student>;
        for(int i=0;i<student.size();i++){
            Student st = student.get(i);
            if(hs.contains(st.getID())){
                // Update
                hs.remove(i);
                student.remove(i);
                i--;
            }
        }
    for(int i=0;i<hs.size();i++){
        // Delete (hs.get(i))
    }  
     for(int i=0;i<student.size();i++){
        // Insert
        String sql = "Insert into studentInfo values ("+student.get(i)+")";
    }  
    }
    
    void myQueue(String sql){
        try{
            PreparedStatement ps = con.prepareStatement(sql);
            ps.execute();
        }catch(Exception e){
        }
    }    
}
